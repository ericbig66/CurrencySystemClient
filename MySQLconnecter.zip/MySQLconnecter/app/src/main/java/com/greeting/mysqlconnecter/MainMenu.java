package com.greeting.mysqlconnecter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainMenu extends AppCompatActivity {
    TextView wmsg;
    Intent intent;
    String acc;
    public void execute(View v){
        switch (v.getId()){
            case R.id.getcoin:
               intent = new Intent(MainMenu.this, Purchase.class);
                break;
            case R.id.paycoin:
                intent = new Intent(MainMenu.this, Gift.class);
                break;
            case R.id.diary:
                intent = new Intent(MainMenu.this, Diary.class);
                break;
        }
        intent.putExtra("acc",acc);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        acc = intent.getStringExtra("acc");
        String msg = intent.getStringExtra("msg");
        setContentView(R.layout.layout_main_menu);
        wmsg = (TextView) findViewById(R.id.msg);
        wmsg.setText(msg);
    }
}
