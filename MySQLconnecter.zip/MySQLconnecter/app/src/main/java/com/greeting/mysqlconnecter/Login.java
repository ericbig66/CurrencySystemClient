package com.greeting.mysqlconnecter;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.sql.Types;



public class Login extends AppCompatActivity {
    //連接資料庫的IP、帳號(不可用root)、密碼
    private static final String url = "jdbc:mysql://140.135.113.196:3360/virtualcurrencyproject";
    private static final String user = "currency";
    private static final String pass = "@SAclass";

    Button btnFetch, btnClear, reg;
    TextView txtData;
    EditText acc, pwd;
    String account, password, data;


public void swreg(){
    Intent intent = new Intent(this, Register.class);
    startActivity(intent);
}

public void swmenu(){
    Intent intent = new Intent(this, MainMenu.class);
    intent.putExtra("acc",account);
    intent.putExtra("msg",data);
    startActivity(intent);
    finish();
}

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_login);

        btnFetch = (Button) findViewById(R.id.btnFetch);//登入
        btnClear = (Button) findViewById(R.id.btnClear);//清除
        reg = (Button) findViewById(R.id.reg);//切換到註冊頁面
        txtData = (TextView) findViewById(R.id.txtData);//登入結果
        acc = (EditText) findViewById(R.id.acc);//帳號(Email)
        pwd = (EditText) findViewById(R.id.pwd);//密碼
//        dtv = (TextView) findViewById(R.id.dtv);

        //註冊紐動作
        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                swreg();
            }
        });

        //登入紐動作
        btnFetch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                account = acc.getText().toString();
                password = pwd.getText().toString();
//                dtv.setText("call login(@fname, "+account+", "+password+"); select @fname;");
                if(account.trim().isEmpty()||password.trim().isEmpty()){
                    Toast.makeText(Login.this,"請輸入帳號密碼以登入!",Toast.LENGTH_SHORT).show();
                }else{
                    ConnectMySql connectMySql = new ConnectMySql();
                    connectMySql.execute("");
                }

            }
        });

        //清除紐動作
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtData.setText("");
                acc.setText(null);
                pwd.setText(null);
            }
        });
    }


    //建立連接與查詢非同步作業
    private class ConnectMySql extends AsyncTask<String, Void, String> {
        String res="";//錯誤信息儲存變數
        //開始執行動作
        @Override
        protected void onPreExecute(){
            super.onPreExecute();
            Toast.makeText(Login.this,"請稍後...",Toast.LENGTH_SHORT).show();
        }
        //查詢執行動作(不可使用與UI相關的指令)
        @Override
        protected String doInBackground(String... strings) {
            try{
                //連接資料庫
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection(url, user, pass);
                //建立查詢
                String result ="";
                //Statement st = con.createStatement();

//                ResultSet rs = st.executeQuery("call login(@fname, '"+account+"', '"+password+"'); select @fname;");
                //experiment part start
                //此處呼叫Stored procedure(call 函數名稱(?)==>問號數量代表輸出、輸入的變數數量)
                CallableStatement cstmt = con.prepareCall("{call login(?,?,?,?,?)}");
                cstmt.registerOutParameter(1, Types.VARCHAR);//設定輸出變數(參數位置,參數型別)
                cstmt.registerOutParameter(2, Types.VARCHAR);
                cstmt.registerOutParameter(3, Types.INTEGER);
                cstmt.setString(4, account);//設定輸入變數(參數位置,輸入值)
                cstmt.setString(5, password);
                cstmt.executeUpdate();
                return cstmt.getString(1)+cstmt.getString(2)+"您好!\n目前您尚有$"+cstmt.getString(3);//回傳結果給onPostExecute==>取得輸出變數(位置)
                //experiment part end
//
//                while(rs.next()){
//                    result += rs.getString(1).toString()+"您好!";

            }catch (Exception e){
//                }
//                res = result;
                e.printStackTrace();
                res = e.toString();
            }
            return res;
        }
        //查詢後的結果將回傳於此
        @Override
        protected void onPostExecute(String result) {

            if (result.equals("null遊客您好!\n目前您尚有$null")){
                result= "遊客您好!\n如需購物請先註冊帳號\n謝謝您的合作!";
                txtData.setText(result);//設定結果顯示
            }
            else{
                data = result;
                Toast.makeText(Login.this, result, Toast.LENGTH_SHORT);
                swmenu();
            }


        }
    }
}
