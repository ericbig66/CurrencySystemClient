package com.greeting.mysqlconnecter;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.content.CursorLoader;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.icu.util.Calendar;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.text.Layout;
import android.util.Base64;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Date;


public class Register extends AppCompatActivity {

    private static final String url = "jdbc:mysql://140.135.113.196:3360/virtualcurrencyproject";
    private static final String user = "currency";
    private static final String pass = "@SAclass";
    static final int OPEN_PIC = 1021;

    EditText ln, fn, em, bd, ad, pwd, chkpwd;
    RadioButton m, f;
    Button pic, reg, login, clr;
    DatePicker dtp;
//    LinearLayout df;
    //系統時間及格式設定
    Date curDate = new Date(System.currentTimeMillis()) ;//取得系統時間
    SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");//格式化日期顯示方式
    //格式化出可直接使用的年月日變數
    SimpleDateFormat year = new SimpleDateFormat("yyyy");
    SimpleDateFormat month = new SimpleDateFormat("mm");
    SimpleDateFormat day = new SimpleDateFormat("dd");
    String yyyy = year.format(curDate);
    String mm = month.format(curDate);
    String dd = day.format(curDate);
    //裝載轉換出的EditText中的文字
    String LN="", FN="" ,EM="" ,AD = "" ,GEN = "" ,PWD = "" ,CHKPWD="" ,BD="";
    //清除所有填寫的資料(會被重新填寫按鈕呼叫或註冊成功時會被呼叫)
    public void clear(){
        ln.setText("");
        fn.setText("");
        em.setText("");
        ad.setText("");
        pwd.setText("");
        bd.setText("");

        chkpwd.setText("");
        LN="";
        FN="";
        EM="";
        AD = "";
        GEN = "";
        PWD = "";
        BD="";
        dtp.init(Integer.parseInt(yyyy), Integer.parseInt(mm), Integer.parseInt(dd), null);
        f.setChecked(false);
        m.setChecked(false);
    }
    //切換回登入模式(被該按鈕呼叫)
    public void swlogin(){
        Intent intent = new Intent(this, Login.class);
        startActivity(intent);
    }

    //隱藏鍵盤
    public void closekeybord() {
        View view = this.getCurrentFocus();
        if(view != null){
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(),0);
        }
    }
    //檢查填寫資料正確性(按下註冊鈕後呼叫)
    public void verify(){
        Boolean haveError = false;
        String err ="";
        err = LN.trim().isEmpty()?err+="姓氏,":err;
        err = FN.trim().isEmpty()?err+="名字,":err;
        err = PWD.trim().isEmpty()?err+="密碼,":err;
        err = CHKPWD.trim().isEmpty()?err+="確認密碼,":err;
        err = EM.trim().isEmpty()?err+="E-mail,":err;
        err = err.isEmpty()?err:err.substring(0, err.length() - 1);
        if(err.isEmpty() == false){err+=" 為必填項目\n請確認是否已填寫!";}
        haveError = err.isEmpty()?false:true;
        if(haveError){Toast.makeText(Register.this, err, Toast.LENGTH_LONG).show();}
        err = "";
        if(PWD.trim().isEmpty()==false && CHKPWD.trim().isEmpty()==false && (PWD.equals(CHKPWD)==false)){
            err += "您輸入的密碼前後不一致，請重新輸入\n";
            chkpwd.setText("");
            CHKPWD = "";
            haveError = true;
        }

        if ( EM.trim().isEmpty() ==false && android.util.Patterns.EMAIL_ADDRESS.matcher(EM).matches() == false ) {
            err += "請輸入正確的電子郵件地址";
            em.setText("");
            EM = "";
            haveError = true;
        }
        if(haveError && err.trim().isEmpty() == false){Toast.makeText(Register.this, err, Toast.LENGTH_LONG).show();}
        if(haveError == false){
            ConnectMySql connectMySql = new ConnectMySql();
            connectMySql.execute("");
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_register);
        ln = (EditText) findViewById(R.id.ln);
        fn = (EditText) findViewById(R.id.fn);
        em = (EditText) findViewById(R.id.em);
        bd = (EditText) findViewById(R.id.bd);
        pwd = (EditText) findViewById(R.id.pwd);
        chkpwd = (EditText) findViewById(R.id.chkpwd);
        ad = (EditText) findViewById(R.id.ad);

        m = (RadioButton) findViewById(R.id.m);
        f = (RadioButton) findViewById(R.id.f);

        pic = (Button) findViewById(R.id.pic);
        reg = (Button) findViewById(R.id.reg);
        login = (Button) findViewById(R.id.login);
        clr = (Button) findViewById(R.id.clr);

        dtp = (DatePicker) findViewById(R.id.dtp);

        dtp.setMaxDate(new Date().getTime());


        pic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               picOpen();
            }
        });




        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                swlogin();
            }
        });

        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closekeybord();
                LN = ln.getText().toString();
                FN = fn.getText().toString();
                EM = em.getText().toString();
                PWD = pwd.getText().toString();
                AD = ad.getText().toString();
                CHKPWD = chkpwd.getText().toString();
                //處理日期問題(月份因預設為0~11故須+1)
                //月分與日期不足10時需增加0以補齊兩位
                String MM,DD;
                MM = (dtp.getMonth()+1)>9?(dtp.getMonth()+1)+"" : "0"+(dtp.getMonth()+1);
                DD = dtp.getDayOfMonth()>9?dtp.getDayOfMonth()+"": "0"+dtp.getDayOfMonth();
                bd.setText(dtp.getYear()+"/"+MM+"/"+DD);
                BD = bd.getText().toString();
                //
                //系統時間格式化(原始以秒為單位)
                String today = formatter.format(curDate);//將今天的日期儲存為指定格式

                if(BD.equals(today)){
                    BD = "";
                }
                verify();
            }
        });

        clr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clear();
            }
        });

        f.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                closekeybord();
                if(isChecked){GEN = "f";}
            }
        });

        m.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                closekeybord();
                if(isChecked){GEN = "m";}
            }
        });
    }

    private class ConnectMySql extends AsyncTask<String, Void, String> {
        String res="";

        @Override
        protected void onPreExecute(){
            super.onPreExecute();
            Toast.makeText(Register.this,"註冊中...",Toast.LENGTH_SHORT).show();
        }

        @Override
        protected String doInBackground(String... strings) {
            try{


                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection(url, user, pass);
                String result ="";
                CallableStatement cstmt = con.prepareCall("{call register(?,?,?,?,?,?,?,?)}");
                cstmt.setString(1, FN);
                cstmt.setString(2, LN);
                cstmt.setString(3, EM);
                cstmt.setString(4, PWD);
                cstmt.setString(5, BD);
                cstmt.setString(6, AD);
                cstmt.setString(7, GEN);
                cstmt.registerOutParameter(8,Types.VARCHAR);
                cstmt.executeUpdate();
                return cstmt.getString(8);

            }catch (Exception e){
                e.printStackTrace();
                res = e.toString();

            }
            return res;
        }

        @Override
        protected void onPostExecute(String result) {
            Toast.makeText(Register.this, result, Toast.LENGTH_SHORT).show();
            if(result.equals("註冊成功!")){
                clear();
                swlogin();
                finish();
            }


        }


    }
    //********************************************************************************************
    //開啟頭像
    public void picOpen(){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, OPEN_PIC);
    }
    //取得圖片路徑
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Toast.makeText(Register.this, "hi!",Toast.LENGTH_SHORT);
        if(requestCode == OPEN_PIC && RESULT_OK == resultCode){
            Uri uri = data.getData();
            try{
                String[] projection = {MediaStore.Images.Media.DATA};
                CursorLoader cursorLoader = new CursorLoader(this, uri, projection, null, null, null);
                Cursor cursor = cursorLoader.loadInBackground();
                int colum_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                cursor.moveToFirst();

                String path = cursor.getString(colum_index);
                encode(path);

            }catch (Exception e){
                Toast.makeText(Register.this,e.toString(),Toast.LENGTH_LONG);
            }
        }
    }
    //將圖片編碼為base64
    private void encode(String path){
        Bitmap bitmap = BitmapFactory.decodeFile(path);
        ByteArrayOutputStream boas = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, boas);
        byte[] bytes = new  byte[100];//???????????
        byte[] encode = Base64.encode(bytes,Base64.DEFAULT);
        String encodeString = new String(encode);
        Toast.makeText(Register.this, encodeString, Toast.LENGTH_LONG);
    }

}

